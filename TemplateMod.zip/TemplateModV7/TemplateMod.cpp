#include <windows.h>
#include <stdio.h>

typedef int (__cdecl *MCModRegisterEntryFn)(const char* ownerMod, const char* internalName, const char* displayName);
typedef int (__cdecl *MCModRegisterEntryExFn)(const char* ownerMod, const char* internalName, const char* displayName, const char* texturePath);
typedef int (__cdecl *MCModResolveByNameFn)(const char* namespacedName);
typedef int (__cdecl *MCModGetRegisteredCountFn)();
typedef void (__cdecl *MCModLogFn)(const char* text);
typedef int (__cdecl *MCModPublishEventFn)(const char* eventName, const void* eventData);
typedef const char* (__cdecl *MCModGetInfoStringFn)(const char* key);
typedef int (__cdecl *MCModGetInfoIntFn)(const char* key);
typedef void (__cdecl *MCModEventCallbackFn)(const char* eventName, const void* eventData, void* userData);
typedef int (__cdecl *MCModSubscribeEventFn)(const char* eventName, MCModEventCallbackFn callback, void* userData);

struct MCModRegistryAPI
{
    int apiVersion;
    MCModRegisterEntryFn registerItem;
    MCModRegisterEntryFn registerBlock;
    MCModRegisterEntryFn registerMob;
    MCModLogFn log;
    MCModRegisterEntryExFn registerItemEx;
    MCModRegisterEntryExFn registerBlockEx;
    void* registerMobEx;
    MCModResolveByNameFn resolveItemId;
    MCModResolveByNameFn resolveBlockId;
    MCModResolveByNameFn resolveEntityId;
    void* getRegisteredItemName;
    void* getRegisteredBlockName;
    void* getRegisteredMobName;
    void* registerMenuType;
    void* registerRecipeType;
    void* registerBlockEntityType;
    void* registerEntityType;
    MCModSubscribeEventFn subscribeEvent;
    void* resolveMenuTypeId;
    void* resolveRecipeTypeId;
    void* resolveBlockEntityTypeId;
    void* resolveCustomEntityTypeId;
    void* getRegisteredMenuTypeName;
    void* getRegisteredRecipeTypeName;
    void* getRegisteredBlockEntityTypeName;
    void* getRegisteredCustomEntityTypeName;
    MCModGetRegisteredCountFn getRegisteredItemCount;
    MCModGetRegisteredCountFn getRegisteredBlockCount;
    MCModGetRegisteredCountFn getRegisteredMobCount;
    void* getRegisteredMenuTypeCount;
    void* getRegisteredRecipeTypeCount;
    void* getRegisteredBlockEntityTypeCount;
    void* getRegisteredCustomEntityTypeCount;
    void* registerShapelessRecipe;
    void* registerOreGen;
    MCModPublishEventFn publishEvent;
    MCModGetInfoStringFn getInfoString;
    MCModGetInfoIntFn getInfoInt;
};

static const int MCMOD_INIT_API_V7 = 7;
static const int MCMOD_INIT_API_V1 = 1;

static FILE* g_log = NULL;
static unsigned int g_ticks = 0;

static void LogLine(const char* text)
{
    if (g_log)
    {
        fprintf(g_log, "%s\n", text);
        fflush(g_log);
    }
    OutputDebugStringA(text);
    OutputDebugStringA("\n");
}

static void __cdecl OnModTickEvent(const char* eventName, const void* eventData, void* userData)
{
    (void)eventData;
    (void)userData;
    if ((g_ticks % 300) == 0)
    {
        char line[160] = {0};
        sprintf_s(line, "[TemplateModV7] Event callback: %s", eventName ? eventName : "<null>");
        LogLine(line);
    }
}

extern "C" __declspec(dllexport) const char* __cdecl MCModGetName()
{
    return "TemplateModV7";
}

extern "C" __declspec(dllexport) int __cdecl MCModInit(int apiVersion)
{
    CreateDirectoryW(L"mods", NULL);
    fopen_s(&g_log, "mods\\TemplateModV7.log", "a+");

    if (apiVersion != MCMOD_INIT_API_V7 && apiVersion != MCMOD_INIT_API_V1)
    {
        LogLine("[TemplateModV7] Unsupported init API");
        return 1;
    }

    LogLine("[TemplateModV7] Init OK");
    g_ticks = 0;
    return 0;
}

extern "C" __declspec(dllexport) void __cdecl MCModTick(float deltaSeconds)
{
    ++g_ticks;
    if ((g_ticks % 600) == 0)
    {
        char line[160] = {0};
        sprintf_s(line, "[TemplateModV7] Tick: %u (dt=%0.3f)", g_ticks, deltaSeconds);
        LogLine(line);
    }
}

extern "C" __declspec(dllexport) void __cdecl MCModShutdown()
{
    LogLine("[TemplateModV7] Shutdown");
    if (g_log)
    {
        fclose(g_log);
        g_log = NULL;
    }
}

extern "C" __declspec(dllexport) void __cdecl MCModRegisterContent(const void* registryApi)
{
    const MCModRegistryAPI* api = (const MCModRegistryAPI*)registryApi;
    if (!api)
    {
        LogLine("[TemplateModV7] RegisterContent got null api");
        return;
    }

    if (api->apiVersion >= 3 && api->registerItemEx)
    {
        api->registerItemEx("TemplateModV7", "template_item", "Template Item", "TemplateModV7/textures/items/template_item.png");
    }
    else if (api->registerItem)
    {
        api->registerItem("TemplateModV7", "template_item", "Template Item");
    }

    if (api->apiVersion >= 3 && api->registerBlockEx)
    {
        api->registerBlockEx("TemplateModV7", "template_block", "Template Block", "TemplateModV7/textures/blocks/template_block.png");
    }
    else if (api->registerBlock)
    {
        api->registerBlock("TemplateModV7", "template_block", "Template Block");
    }

    if (api->subscribeEvent)
    {
        api->subscribeEvent("OnModTick", &OnModTickEvent, NULL);
    }

    if (api->apiVersion >= 7)
    {
        if (api->getInfoString && api->getInfoInt)
        {
            const char* platform = api->getInfoString("platform");
            int loadedMods = api->getInfoInt("loaded_mods");
            char line[192] = {0};
            sprintf_s(line, "[TemplateModV7] platform=%s loaded_mods=%d", platform ? platform : "unknown", loadedMods);
            if (api->log)
            {
                api->log(line);
            }
            LogLine(line);
        }

        if (api->publishEvent)
        {
            api->publishEvent("templatemod.ready", NULL);
        }
    }

    if (api->log)
    {
        api->log("TemplateModV7 registered content");
    }
}
