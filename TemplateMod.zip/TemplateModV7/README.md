# Template Mod V7 (Windows64)

This is a GitHub-ready starter template for the Windows64 DLL mod loader.

It targets Mod API V7 and still accepts the legacy init API for compatibility.

## What This Template Gives You

- A working DLL project for VS2022
- Required loader exports:
  - MCModGetName
  - MCModInit
  - MCModTick
  - MCModShutdown
  - MCModRegisterContent (optional but included)
- Example content registration (item + block)
- Example V7 extension hooks:
  - subscribeEvent("OnModTick", ...)
  - getInfoString("platform")
  - getInfoInt("loaded_mods")
  - publishEvent("templatemod.ready", ...)

## Files

- TemplateMod.sln
- TemplateMod.vcxproj
- TemplateMod.cpp

## Build

1. Open TemplateMod.sln in Visual Studio 2022.
2. Select Release | x64.
3. Build the project.

Output DLL location:

- ..\x64\Release\mods\TemplateModV7.dll

## Drop-In Locations Used by Loader

Primary:

- Minecraft.Client\mods\*.dll
- Minecraft.Client\*.mcmod.dll

## V7 API Notes

The loader now negotiates init API like this:

1. Tries MCModInit(7)
2. Falls back to MCModInit(1) if the mod rejects 7

Registry API table version is 7 and includes new helpers:

- publishEvent(eventName, eventData)
- getInfoString(key)
- getInfoInt(key)

Useful keys:

- getInfoString("platform") -> Windows64
- getInfoString("api.init") -> 7
- getInfoString("api.registry") -> 7
- getInfoInt("loaded_mods")
- getInfoInt("registered_items")
- getInfoInt("registered_blocks")
- getInfoInt("registered_mobs")
- getInfoInt("tick_index")

## Content Namespace Convention

Always namespace your content(java like):

- Owner mod: TemplateModV7
- Item IDs: TemplateModV7:your_item
- Block IDs: TemplateModV7:your_block

This avoids collisions with other DLL mods.

## Publishing This To GitHub

Recommended repo structure:

- /TemplateModV7/TemplateMod.sln
- /TemplateModV7/TemplateMod.vcxproj
- /TemplateModV7/TemplateMod.cpp
- /TemplateModV7/README.md

## There will be more documentation soon, I am getting to it